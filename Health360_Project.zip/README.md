# Health360: Comprehensive Healthcare Risk & Disease Analytics

Health360 is a responsive front-end educational dashboard that demonstrates how fictional healthcare indicators can be presented in a clear analytics interface.

## Features
- Responsive dashboard for desktop and mobile
- Summary cards and illustrative risk distribution
- Patient record search by name or ID
- Filters for risk level and condition
- Export fictional sample records to CSV
- Mobile navigation
- Clear medical safety disclaimer

## Tech stack
HTML5, CSS3, Vanilla JavaScript.

## Run locally
Download the files and open `index.html` in a web browser. No installation or build step is required.

## Publish with GitHub Pages
1. Open repository **Settings**.
2. Select **Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Choose branch `main` and folder `/(root)`, then select **Save**.
5. Open the Pages URL shown after GitHub finishes deploying.

## Important safety note
This is an educational UI prototype only. All records and metric values are fictional. It does not diagnose, predict, or replace a healthcare professional. Do not enter real patient information or use this demo to make medical decisions.
