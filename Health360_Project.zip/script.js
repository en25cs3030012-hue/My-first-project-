const patients=[
{name:"Aarav Mehta",id:"H360-001",age:45,condition:"Heart",risk:"High",review:"12 Oct 2026"},
{name:"Diya Sharma",id:"H360-002",age:34,condition:"Diabetes",risk:"Low",review:"10 Oct 2026"},
{name:"Kabir Patel",id:"H360-003",age:62,condition:"Heart",risk:"High",review:"09 Oct 2026"},
{name:"Anaya Singh",id:"H360-004",age:51,condition:"None",risk:"Low",review:"08 Oct 2026"},
{name:"Ishaan Verma",id:"H360-005",age:57,condition:"Diabetes",risk:"Moderate",review:"07 Oct 2026"},
{name:"Meera Joshi",id:"H360-006",age:48,condition:"Stroke",risk:"Moderate",review:"05 Oct 2026"},
{name:"Reyansh Shah",id:"H360-007",age:69,condition:"Heart",risk:"High",review:"03 Oct 2026"},
{name:"Sara Khan",id:"H360-008",age:41,condition:"None",risk:"Low",review:"01 Oct 2026"}];
const $=id=>document.getElementById(id);
function render(){const term=$("search").value.toLowerCase().trim(),risk=$("risk").value,condition=$("condition").value;const list=patients.filter(p=>(p.name+" "+p.id).toLowerCase().includes(term)&&(risk==="all"||p.risk===risk)&&(condition==="all"||p.condition===condition));$("rows").innerHTML=list.map(p=>`<tr><td><span class="person">${p.name}</span><span class="id">${p.id}</span></td><td>${p.age} yrs</td><td>${p.condition==="None"?"No indicator listed":p.condition}</td><td><span class="badge ${p.risk}">${p.risk}</span></td><td>${p.review}</td></tr>`).join("");$("empty").hidden=list.length>0;$("count").textContent=`Showing ${list.length} of ${patients.length} sample records`;}
["search","risk","condition"].forEach(id=>$(id).addEventListener("input",render));
$("exportBtn").addEventListener("click",()=>{const data=[["Patient","ID","Age","Primary indicator","Risk level","Last review"],...patients.map(p=>[p.name,p.id,p.age,p.condition,p.risk,p.review])];const csv=data.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n");const url=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));const a=document.createElement("a");a.href=url;a.download="health360-sample-records.csv";a.click();URL.revokeObjectURL(url);});
$("menuBtn").addEventListener("click",()=>$("sidebar").classList.toggle("open"));document.querySelectorAll(".nav").forEach(a=>a.addEventListener("click",()=>$("sidebar").classList.remove("open")));render();
