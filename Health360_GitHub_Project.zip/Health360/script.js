const patients = [
  {id:"H360-001", age:"50–59", indicators:"Blood pressure, family history", risk:"High", next:"Clinical review recommended"},
  {id:"H360-002", age:"30–39", indicators:"Glucose indicator", risk:"Moderate", next:"Routine follow-up"},
  {id:"H360-003", age:"40–49", indicators:"BMI category", risk:"Low", next:"Continue routine care"},
  {id:"H360-004", age:"60–69", indicators:"Blood pressure, glucose", risk:"High", next:"Clinical review recommended"},
  {id:"H360-005", age:"20–29", indicators:"Family history", risk:"Low", next:"Routine wellness check"},
  {id:"H360-006", age:"40–49", indicators:"Glucose, BMI category", risk:"Moderate", next:"Routine follow-up"},
  {id:"H360-007", age:"50–59", indicators:"Blood pressure", risk:"High", next:"Clinical review recommended"},
  {id:"H360-008", age:"30–39", indicators:"No major demo flags", risk:"Low", next:"Continue routine care"},
  {id:"H360-009", age:"60–69", indicators:"Blood pressure, family history", risk:"Moderate", next:"Routine follow-up"},
  {id:"H360-010", age:"40–49", indicators:"Glucose indicator", risk:"Moderate", next:"Routine follow-up"}
];
const tbody = document.getElementById("patientRows");
const search = document.getElementById("searchInput");
function renderRows(query = "") {
  const filtered = patients.filter(p => Object.values(p).join(" ").toLowerCase().includes(query.toLowerCase()));
  tbody.innerHTML = filtered.length ? filtered.map(p => `
    <tr><td>${p.id}</td><td>${p.age}</td><td>${p.indicators}</td>
    <td><span class="risk ${p.risk.toLowerCase()}">${p.risk}</span></td><td>${p.next}</td></tr>`).join("")
    : '<tr><td colspan="5">No matching sample records found.</td></tr>';
}
search.addEventListener("input", e => renderRows(e.target.value));
renderRows();
